This is just a simple example of how to write a maya exporter. This basically has more or less
the same functionality as the obj export that comes with maya. Probably a fairly nice place to
start for those new to the maya API.

For linux users, ensure that mayald is executable when compiling, each folder has its own
Makefile. In the main directory is a little bash script that compiles both projects. Ensure
that 'build' is executable, and then execute ./build to re-make

rob bateman 29/July/04
